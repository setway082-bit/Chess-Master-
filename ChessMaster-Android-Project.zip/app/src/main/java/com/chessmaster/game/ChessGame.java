package com.chessmaster.game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class ChessGame {
    // White pieces are positive, black pieces negative: pawn=1, knight=2, bishop=3, rook=4, queen=5, king=6.
    int[] board = new int[64];
    int turn=1, ep=-1, castle=15, halfmove=0, fullmove=1;
    private final List<State> history = new ArrayList<>();
    ChessGame() { reset(); }
    void reset() {
        int[] start={-4,-2,-3,-5,-6,-3,-2,-4,-1,-1,-1,-1,-1,-1,-1,-1,
                     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
                     1,1,1,1,1,1,1,1,4,2,3,5,6,3,2,4};
        board=start; turn=1; ep=-1; castle=15; halfmove=0; fullmove=1; history.clear(); save();
    }
    private static class State {
        int[] b; int t,e,c,h,f;
        State(ChessGame g){b=g.board.clone();t=g.turn;e=g.ep;c=g.castle;h=g.halfmove;f=g.fullmove;}
    }
    private void save(){history.add(new State(this));}
    void undo(){
        if(history.size()<=1)return;
        history.remove(history.size()-1); State s=history.get(history.size()-1);
        board=s.b.clone();turn=s.t;ep=s.e;castle=s.c;halfmove=s.h;fullmove=s.f;
    }
    List<Integer> destinations(int from){
        List<Integer> out=new ArrayList<>();
        for(int[] m:allMoves()) if(m[0]==from) out.add(m[1]);
        return out;
    }
    List<int[]> allMoves(){
        List<int[]> out=new ArrayList<>();
        for(int i=0;i<64;i++) if(board[i]!=0 && Integer.signum(board[i])==turn)
            for(int j=0;j<64;j++) if(isLegal(i,j)) out.add(new int[]{i,j});
        return out;
    }
    boolean isLegal(int from,int to){
        if(from==to || board[from]==0 || (board[to]!=0 && Integer.signum(board[to])==turn))return false;
        int p=Math.abs(board[from]), dr=to/8-from/8, dc=to%8-from%8, ad=Math.abs(dr), ac=Math.abs(dc);
        boolean ok=false;
        if(p==1){
            int dir=turn==1?-1:1, start=turn==1?6:1;
            if(dc==0 && dr==dir && board[to]==0)ok=true;
            if(dc==0 && dr==2*dir && from/8==start && board[to]==0 && board[from+dir*8]==0)ok=true;
            if(ac==1 && dr==dir && ((board[to]!=0 && Integer.signum(board[to])==-turn)||to==ep))ok=true;
        } else if(p==2) ok=(ad==2&&ac==1)||(ad==1&&ac==2);
        else if(p==3||p==4||p==5){
            boolean diagonal=ad==ac&&ad>0, straight=(dr==0)^(dc==0);
            if((p==3&&diagonal)||(p==4&&straight)||(p==5&&(diagonal||straight))){
                int sr=Integer.signum(dr),sc=Integer.signum(dc),r=from/8+sr,c=from%8+sc;ok=true;
                while(r!=to/8||c!=to%8){if(board[r*8+c]!=0){ok=false;break;}r+=sr;c+=sc;}
            }
        } else if(p==6){
            if(Math.max(ad,ac)==1)ok=true;
            if(dr==0&&ac==2&&canCastle(from,to))ok=true;
        }
        if(!ok)return false;
        ChessGame copy=new ChessGame(false); copy.copyFrom(this); copy.rawMove(from,to);
        return !copy.inCheck(turn);
    }
    private ChessGame(boolean ignored) {}
    private void copyFrom(ChessGame g){board=g.board.clone();turn=g.turn;ep=g.ep;castle=g.castle;halfmove=g.halfmove;fullmove=g.fullmove;}
    private boolean canCastle(int from,int to){
        if(inCheck(turn))return false;
        if(turn==1&&from==60&&to==62&&(castle&1)!=0&&board[61]==0&&board[62]==0&&board[63]==4)
            return !attacked(61,-turn)&&!attacked(62,-turn);
        if(turn==1&&from==60&&to==58&&(castle&2)!=0&&board[59]==0&&board[58]==0&&board[57]==0&&board[56]==4)
            return !attacked(59,-turn)&&!attacked(58,-turn);
        if(turn==-1&&from==4&&to==6&&(castle&4)!=0&&board[5]==0&&board[6]==0&&board[7]==-4)
            return !attacked(5,-turn)&&!attacked(6,-turn);
        if(turn==-1&&from==4&&to==2&&(castle&8)!=0&&board[3]==0&&board[2]==0&&board[1]==0&&board[0]==-4)
            return !attacked(3,-turn)&&!attacked(2,-turn);
        return false;
    }
    private boolean attacked(int sq,int by){
        for(int i=0;i<64;i++) if(board[i]!=0&&Integer.signum(board[i])==by){
            int p=Math.abs(board[i]),dr=sq/8-i/8,dc=sq%8-i%8,ad=Math.abs(dr),ac=Math.abs(dc);
            if(p==1&&dr==(by==1?-1:1)&&ac==1)return true;
            if(p==2&&((ad==2&&ac==1)||(ad==1&&ac==2)))return true;
            if(p==6&&Math.max(ad,ac)==1)return true;
            if(p==3||p==4||p==5){
                boolean diag=ad==ac&&ad>0,straight=(dr==0)^(dc==0);
                if((p==3&&diag)||(p==4&&straight)||(p==5&&(diag||straight))){
                    int sr=Integer.signum(dr),sc=Integer.signum(dc),r=i/8+sr,c=i%8+sc;boolean clear=true;
                    while(r!=sq/8||c!=sq%8){if(board[r*8+c]!=0){clear=false;break;}r+=sr;c+=sc;}
                    if(clear)return true;
                }
            }
        }
        return false;
    }
    private boolean inCheck(int side){
        int king=-1;for(int i=0;i<64;i++)if(board[i]==side*6){king=i;break;}
        return king<0||attacked(king,-side);
    }
    void move(int from,int to){
        if(!isLegal(from,to))return;
        rawMove(from,to); save();
    }
    private void rawMove(int from,int to){
        int p=board[from],captured=board[to],oldTurn=turn;
        if(Math.abs(p)==1&&to==ep&&captured==0){board[to+(oldTurn==1?8:-8)]=0;captured=oldTurn==1?-1:1;}
        board[to]=p;board[from]=0;
        if(Math.abs(p)==6&&Math.abs(to-from)==2){
            if(to>from){board[to-1]=board[to+1];board[to+1]=0;}
            else {board[to+1]=board[to-2];board[to-2]=0;}
        }
        if(Math.abs(p)==1&&(to/8==0||to/8==7))board[to]=oldTurn*5;
        if(p==6)castle&=~3;if(p==-6)castle&=~12;
        if(from==63||to==63)castle&=~1;if(from==56||to==56)castle&=~2;
        if(from==7||to==7)castle&=~4;if(from==0||to==0)castle&=~8;
        ep=(Math.abs(p)==1&&Math.abs(to-from)==16)?(to+from)/2:-1;
        halfmove=(Math.abs(p)==1||captured!=0)?0:halfmove+1;
        if(oldTurn==-1)fullmove++;
        turn=-oldTurn;
    }
    boolean finished(){return allMoves().isEmpty()||halfmove>=100;}
    String status(){
        List<int[]> m=allMoves();
        if(m.isEmpty())return inCheck(turn)?"CHECKMATE  ·  "+(turn==1?"BLACK":"WHITE")+" WINS":"DRAW  ·  STALEMATE";
        if(halfmove>=100)return "DRAW  ·  50-MOVE RULE";
        return (turn==1?"WHITE":"BLACK")+" TO MOVE"+(inCheck(turn)?"  ·  CHECK":"");
    }
}
