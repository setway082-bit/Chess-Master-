package com.chessmaster.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {
    private ChessGame game = new ChessGame();
    private TextView status, modeLabel;
    private Button[][] cells = new Button[8][8];
    private int selected = -1;
    private List<Integer> targets = new ArrayList<>();
    private boolean vsComputer = true;
    private final String[] glyphs = {"", "♙", "♘", "♗", "♖", "♕", "♔", "♟", "♞", "♝", "♜", "♛", "♚"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,24,32));
        getWindow().setNavigationBarColor(Color.rgb(16,24,32));
        buildUi();
        refresh();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void buildUi() {
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(14), dp(16), dp(12)); page.setBackgroundColor(Color.rgb(16,24,32));
        setContentView(page);

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("♟  CHESS MASTER", 22, Color.WHITE, true);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button restart = button("↻", "#243746"); restart.setTextSize(23);
        restart.setOnClickListener(v -> { game = new ChessGame(); selected=-1; targets.clear(); refresh(); });
        header.addView(restart, new LinearLayout.LayoutParams(dp(52), dp(46)));
        page.addView(header);

        status = text("White to move", 16, Color.rgb(222,235,241), true);
        status.setGravity(Gravity.CENTER_VERTICAL);
        status.setPadding(dp(4), dp(8), dp(4), dp(8));
        page.addView(status);

        GridLayout board = new GridLayout(this); board.setColumnCount(8); board.setRowCount(8);
        board.setBackground(bg(Color.rgb(11,17,23), 10)); board.setPadding(dp(3),dp(3),dp(3),dp(3));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 0, 1);
        bp.gravity = Gravity.CENTER; bp.topMargin=dp(5); bp.bottomMargin=dp(12);
        page.addView(board, bp);
        for (int r=0;r<8;r++) for(int c=0;c<8;c++) {
            final int sq=r*8+c;
            Button cell = new Button(this); cells[r][c]=cell;
            cell.setAllCaps(false); cell.setPadding(0,0,0,0); cell.setMinWidth(0); cell.setMinimumWidth(0);
            cell.setMinHeight(0); cell.setMinimumHeight(0); cell.setTextSize(30);
            GridLayout.LayoutParams p = new GridLayout.LayoutParams(
                GridLayout.spec(r,1,1f), GridLayout.spec(c,1,1f));
            p.width=0; p.height=0; p.setMargins(0,0,0,0);
            board.addView(cell,p);
            cell.setOnClickListener(v -> tap(sq));
        }

        modeLabel = text("MODE  ·  VS COMPUTER", 13, Color.rgb(22,199,154), true);
        modeLabel.setPadding(dp(4),dp(4),dp(4),dp(8)); page.addView(modeLabel);

        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button undo = button("UNDO", "#243746");
        undo.setOnClickListener(v -> { game.undo(); selected=-1; targets.clear(); refresh(); });
        Button mode = button("2 PLAYERS", "#243746");
        mode.setOnClickListener(v -> { vsComputer=!vsComputer; game=new ChessGame(); selected=-1; targets.clear(); refresh(); });
        Button newGame = button("NEW GAME", "#147D66");
        newGame.setOnClickListener(v -> { game=new ChessGame(); selected=-1; targets.clear(); refresh(); });
        actions.addView(undo,new LinearLayout.LayoutParams(0,dp(48),1));
        actions.addView(mode,new LinearLayout.LayoutParams(0,dp(48),1));
        actions.addView(newGame,new LinearLayout.LayoutParams(0,dp(48),1));
        page.addView(actions);
        TextView foot=text("Select a piece, then tap a highlighted square.",12,Color.rgb(143,161,173),false);
        foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(12),0,0); page.addView(foot);
    }
    private Button button(String label, String color) {
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setPadding(dp(3),0,dp(3),0);
        b.setBackground(bg(Color.parseColor(color),12)); return b;
    }
    private void tap(int sq) {
        if(game.finished() || (vsComputer && game.turn== -1)) return;
        int piece=game.board[sq];
        if(selected<0) {
            if(piece!=0 && Integer.signum(piece)==game.turn) {
                selected=sq; targets=game.destinations(sq); refresh();
            }
        } else {
            if(targets.contains(sq)) {
                game.move(selected,sq); selected=-1; targets.clear(); refresh();
                if(vsComputer && !game.finished() && game.turn==-1) {
                    List<int[]> moves=game.allMoves();
                    if(!moves.isEmpty()) {
                        int[] m=moves.get(new Random().nextInt(moves.size()));
                        game.move(m[0],m[1]); refresh();
                    }
                }
            } else if(piece!=0 && Integer.signum(piece)==game.turn) {
                selected=sq; targets=game.destinations(sq); refresh();
            } else { selected=-1; targets.clear(); refresh(); }
        }
    }
    private void refresh() {
        for(int r=0;r<8;r++) for(int c=0;c<8;c++) {
            int sq=r*8+c, piece=game.board[sq];
            Button b=cells[r][c];
            int base=((r+c)%2==0)?Color.rgb(235,238,216):Color.rgb(119,149,99);
            if(sq==selected) base=Color.rgb(245,208,91);
            else if(targets.contains(sq)) base=Color.rgb(130,190,122);
            b.setBackgroundColor(base);
            b.setText(piece==0?"":glyph[Math.abs(piece)+(piece<0?6:0)]);
            b.setTextColor(piece>0?Color.rgb(255,255,248):Color.rgb(25,30,35));
        }
        modeLabel.setText(vsComputer?"MODE  ·  VS COMPUTER":"MODE  ·  TWO PLAYERS");
        String s=game.status();
        status.setText(s);
    }
}
