# Chess Master Android

A starter Android chess app with a modern dark interface, local two-player mode, and a simple random-move computer opponent.

## Build with GitHub Actions
1. Create a GitHub repository named `ChessMaster`.
2. Upload the **contents** of this folder (not the outer folder itself) to the repository's `main` branch.
3. Open **Actions**. The `Build Android APK` workflow runs automatically.
4. Open the successful workflow run and download the `ChessMaster-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on your Android phone.

## Build configuration
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- compileSdk 35 / minSdk 23

## Notes
This is a clean starter project. The computer opponent currently chooses a random legal move; it is not a chess-strength engine. Pawn promotion currently defaults to a queen. The app includes ordinary piece movement, check legality, castling, en passant, undo, checkmate and stalemate detection.
